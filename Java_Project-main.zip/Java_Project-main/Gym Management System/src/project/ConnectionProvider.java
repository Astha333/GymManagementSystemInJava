/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;
import java.sql.*;

/**
 *
 * @author FX504
 */
public class ConnectionProvider {
    public static Connection getCon()
    {
        try
        {
            Class.forName("class.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gms","root","123456");
            return con;
        }
        catch(Exception e)
        {
            return null;
        }
    }
    
}
